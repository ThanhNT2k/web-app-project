HUONG DAN SU DUNG TREN OVERLEAF

1. Chon New Project -> Upload Project va tai file ZIP nay len.
2. Mo Menu -> Compiler -> pdfLaTeX.
3. Chon main.tex la Main document neu Overleaf chua tu nhan dien.
4. Bam Recompile. Muc luc, danh muc hinh va danh muc bang co the can 2 lan bien dich.

CAC FILE CAN THIET
- main.tex: noi dung va dinh dang bao cao.
- cmc_logo.png: logo tren trang bia.
- erd.png: so do co so du lieu o trang landscape.

LUU Y TRUOC KHI NOP
- Xac nhan lai bang phan cong thanh vien voi minh chung thuc te cua nhom.
- Cap nhat link repository/deployment neu giang vien yeu cau.
- Chay lai CI va Playwright sau khi cai Chromium, sau do cap nhat trang thai E2E neu co ket qua moi.
- Khong dua file .env, API key, token hoac du lieu production vao Overleaf.

Ban source da duoc bien dich kiem tra: 42 trang, khong co loi LaTeX, khong co
undefined control sequence va khong co overfull hbox/vbox.
